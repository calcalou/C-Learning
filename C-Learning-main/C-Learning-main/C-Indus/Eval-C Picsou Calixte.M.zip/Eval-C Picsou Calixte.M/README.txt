==================== Calixte MACQUERON ====================

Fichier compilés ; Nom fichier éxécutable : "MAIN.exe"

Vidéo rapide de démonstration à la source du fichier.

Trois fichier compose le projet : 

main.c : contien : 
-Menu
-Appel des fonctions

Fonction.c : contien : 
-Fonction Créer un compte
-Faire un dépot
-Faire un retrait

Header.h : contien :
-Définitions des structures
-Définitions des fonctions

===========================================================